------ Cara Menjalankan Virus ------

1. Ketikan di termux python2 vbug.py dan enter.
2. Tekan enter lagi
3. Akan ada pilihan pembuatan virus untuk android, windows, macOSX 
4. Ikuti petunjuk selanjutnya
5. Sebarkan virus.apk
